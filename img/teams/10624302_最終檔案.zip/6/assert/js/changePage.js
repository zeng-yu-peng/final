function to2(){
	document.getElementById("page1").style.display="none";
	document.getElementById("page2").style.display="block";
}