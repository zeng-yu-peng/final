

function phoness(){
	var a=document.getElementById("phones");
	a.style.display="block";
}
function mailss(){
	var a=document.getElementById("mails");
	a.style.display="block";
}
function locatess(){
	var a=document.getElementById("locates");
	a.style.display="block";
}
function pw(){
	var a=document.getElementById("password");
	a.style.display="block";
}
function name1(){
	var a=document.getElementById("name");
	a.style.display="block";
}
