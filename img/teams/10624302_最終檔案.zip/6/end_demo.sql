/*
Navicat MySQL Data Transfer

Source Server         : Q
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : end_demo

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2020-01-02 21:18:49
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `adminlist`
-- ----------------------------
DROP TABLE IF EXISTS `adminlist`;
CREATE TABLE `adminlist` (
  `memberid` varchar(255) NOT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adminlist
-- ----------------------------
INSERT INTO adminlist VALUES ('1111');

-- ----------------------------
-- Table structure for `board`
-- ----------------------------
DROP TABLE IF EXISTS `board`;
CREATE TABLE `board` (
  `product` varchar(255) NOT NULL,
  `star` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of board
-- ----------------------------

-- ----------------------------
-- Table structure for `cars`
-- ----------------------------
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `memberid` varchar(255) NOT NULL,
  `productid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `carid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cars
-- ----------------------------
INSERT INTO cars VALUES ('1111', '1', '1', '5');
INSERT INTO cars VALUES ('1111', '2', '1', '5');
INSERT INTO cars VALUES ('1111', '14', '1', '5');
INSERT INTO cars VALUES ('1111', '10', '5', '5');
INSERT INTO cars VALUES ('1111', '5', '1', '7');

-- ----------------------------
-- Table structure for `carsure`
-- ----------------------------
DROP TABLE IF EXISTS `carsure`;
CREATE TABLE `carsure` (
  `memberid` varchar(255) NOT NULL,
  `carid` int(11) NOT NULL AUTO_INCREMENT,
  `payment` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  PRIMARY KEY (`carid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of carsure
-- ----------------------------
INSERT INTO carsure VALUES ('1111', '1', '3', 'WWWWW');
INSERT INTO carsure VALUES ('1111', '2', '1', 'E');
INSERT INTO carsure VALUES ('1111', '3', '1', 'SW');
INSERT INTO carsure VALUES ('1111', '4', '1', 'SW');
INSERT INTO carsure VALUES ('1111', '5', '1', 'SW');
INSERT INTO carsure VALUES ('1111', '6', '2', 'SERW');
INSERT INTO carsure VALUES ('1111', '7', '1', 'S');
INSERT INTO carsure VALUES ('1111', '8', '1', 'SDE');
INSERT INTO carsure VALUES ('1111', '9', '1', 'SDS');

-- ----------------------------
-- Table structure for `detail`
-- ----------------------------
DROP TABLE IF EXISTS `detail`;
CREATE TABLE `detail` (
  `ID` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `information` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `stock` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of detail
-- ----------------------------
INSERT INTO detail VALUES ('1', '卡迪那', '獨特的通心口造型，香脆口感加倍\r\n滿嘴誘人的蕃茄香，多層次口感在味蕾擴散開來\r\n', '', '', '', '01.jpg');
INSERT INTO detail VALUES ('2', '.浪味仙', '甜甜鹹鹹的美妙滋味、兒時回憶!\r\n五辛素植物，風味獨特\r\n口感絕佳，絕不含防腐劑', '', '', '', '02.jpg');
INSERT INTO detail VALUES ('3', '可樂果', '堅持選用天然豌豆作為原料\r\n盡情享受最健康的休閒好味道\r\n', '', '', '', '03.jpg');
INSERT INTO detail VALUES ('4', '樂事 ', '爽口得好味道~~讓人一口接一口~\r\n', '', '', '', '04.jpg');
INSERT INTO detail VALUES ('5', '科學麵', '童年的零食回憶\r\n鹹鹹脆脆好滋味\r\n吃出台灣味', '', '', '', '05.jpg');
INSERT INTO detail VALUES ('6', '.義美夾心酥', '層層酥脆\r\n一口接一口也不會膩', '', '', '', '06.jpg');
INSERT INTO detail VALUES ('7', '方塊酥 ', '酥脆特殊的好口感\r\n多層次餅皮的香氣\r\n樸實甜美的風味', '', '', '', '07.jpg');
INSERT INTO detail VALUES ('8', '蜜蘭諾', '歐洲大師手藝，傳承經典美味\r\n頂級白巧風味包覆百層派皮，香氣濃郁\r\n杏仁脆粒點綴口感細緻，風味優雅~\r\n', '', '', '', '08.jpg');
INSERT INTO detail VALUES ('9', '義美蛋捲', '層層酥鬆，濃醇香氣， 每一口都是幸福滋味\r\n', '', '', '', '09.jpg');
INSERT INTO detail VALUES ('10', '.爆米香', '純手工捏製米香，保證使用合格原物料，米香一律蛋奶素喔！', '', '', '', '10.jpg');
INSERT INTO detail VALUES ('11', '孔雀餅乾', '符合中元節慶澎派氣氛\r\n餅乾酥鬆口感&濃郁蛋香', '', '', '', '11.jpg');
INSERT INTO detail VALUES ('12', '森永牛奶糖', '.森永牛奶糖\r\n獨一無二的香濃滋味\r\n無法忘懷的經典\r\njpg', '', '', '', '12.jpg');
INSERT INTO detail VALUES ('13', '金門貢糖', '香酥柔軟 甜而不膩\r\n入口即化 香味四溢\r\n金門貢糖人氣第一首選', '', '', '', '13.jpg');
INSERT INTO detail VALUES ('14', '牛軋糖', '嚴選台灣北港11號花生採鮮烘\r\n入口時奶香味濃郁\r\nＱ軟不硬，不黏牙', '', '', '', '14.jpg');
INSERT INTO detail VALUES ('15', '乖乖軟糖 ', '陪小朋友一起長大的乖乖\r\n外出郊遊的最佳夥伴\r\n經濟實惠的好選擇', '', '', '', '15.jpg');
INSERT INTO detail VALUES ('16', '嗨啾軟糖 ', 'juicy up美味再升級!\r\n嗨啾繽紛變身更juicy!\r\n', '', '', '', '16.jpg');
INSERT INTO detail VALUES ('17', '77乳加巧克力', '滑順牛奶巧克力MIX奶香牛軋糖\r\n每一口都有粒粒飽滿的花生顆粒', '', '', '', '17.jpg');
INSERT INTO detail VALUES ('18', '健達巧克力', '牛奶巧克力含豐富牛奶內餡\r\n孩子喜歡，媽媽放心', '', '', '', '18.jpg');
INSERT INTO detail VALUES ('19', '大波露 ', '香醇牛奶調配的牛奶巧克力\r\n濃郁滑順的好滋味令人難以抗拒\r\n永遠吃不膩的經典風味\r\n', '', '', '', '19.jpg');
INSERT INTO detail VALUES ('20', '雷神巧克力 ', '日本原裝進口\r\n酥脆好滋味，讓你一口接一口\r\n點心零食好選擇', '', '', '', '20.jpg');
INSERT INTO detail VALUES ('21', '.曾拌麵', '各大綜藝節目介紹藝人朋友推薦\r\n美國權威部落客五星級評價\r\n手工製麵、改良波浪厚芯麵\r\n', '', '', '', '21.jpg');
INSERT INTO detail VALUES ('22', '詹麵', '\r\n博多拉麵麵體，煮熟只需2分半\r\n立體口感好，吸附醬汁更飽滿\r\n不過度烹調，能吃到小麥麵香', '', '', '', '22.jpg');
INSERT INTO detail VALUES ('23', '老媽拌麵', '嚴選台灣特產山珍香菇\r\n台南日曬關廟麵+手工熬煮醬料\r\n外銷各國、網購團購人氣商品', '', '', '', '23.jpg');
INSERT INTO detail VALUES ('24', '滿漢大餐', '青蔥以熱油爆炒獨特香氣\r\n搭配數種香辛料、發酵醬料、牛肉\r\n熬出敦厚嗆辣風味\r\n', '', '', '', '24.jpg');
INSERT INTO detail VALUES ('25', '.來一客', '來自大海的清甜蝦仁\r\n搭配小巧可愛的魚板\r\n佐以海帶嫩芽的鮮美湯頭', '', '', '', '25.jpg');
INSERT INTO detail VALUES ('26', '雙響砲', '一碗美味的雙響砲,cp值超高\r\n濃郁的口感,香氣逼人的美味\r\n療癒人心的美味!!\r\n', '', '', '', '26.jpg');
INSERT INTO detail VALUES ('27', '日清杯麵', '日本原裝進口\r\n香醇濃郁的扇貝海鮮風味\r\n麵條香Q滑順', '', '', '', '27.jpg');
INSERT INTO detail VALUES ('28', '花雕雞麵', '百年老店台酒公司\r\n獨家料理酒包、鮮嫩雞肉料理包\r\n濃郁的湯頭加上香Q的細麵\r\n', '', '', '', '28.jpg');
INSERT INTO detail VALUES ('29', '一度贊 ', '新鮮豬肉加上獨特秘方調味\r\n獨特口味，老饕最愛', '', '', '', '29.jpg');
INSERT INTO detail VALUES ('30', '統一肉燥麵', '道地熟悉的美味\r\n家鄉般的溫暖美味\r\n傳統熟悉的肉燥香味\r\n', '', '', '', '30.jpg');
INSERT INTO detail VALUES ('31', '維力炸醬麵 ', '懷念的好味道麵體Q、料香濃獨特口味，老饕最愛', '', '', '', '31.jpg');

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `ID` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login
-- ----------------------------

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` varchar(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `E_mail` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `birthday` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO member VALUES ('member8', '2', 'f', '1', 'ss@ss', '1', '2', '2019-12-03');
INSERT INTO member VALUES ('member9', '2', 'man', '1', 'ss@ss', '1', '2', '2019-12-04');
INSERT INTO member VALUES ('2222', '2', 'man', '1', 'ss@ss', '1', '2', '2019-12-04');
INSERT INTO member VALUES (null, '2', 'man', '1', 'ss@ss', '1', '2', '2019-12-26');
INSERT INTO member VALUES (null, '2', 'man', '1', 'ss@ss', '1', '2', '2019-12-03');
INSERT INTO member VALUES ('member88', '2', 'female', '1', 'ss@ss', '1', '2', '2019-12-10');
INSERT INTO member VALUES ('memb', '2', 'man', '1', 'ss@ss', '1', '2', '2019-12-04');
INSERT INTO member VALUES ('S', '2', 'female', '1', 'ss@ss', '1', '2', '2019-12-02');
INSERT INTO member VALUES ('1111', '2', 'f', '1', 'ss@ss', '1', '2', '2019-12-22');
INSERT INTO member VALUES ('null', '2', 'man', '1', 'ss@ss', '1', '2', '2018-11-29');
INSERT INTO member VALUES ('null', '2', 'man', '1', 'ss@ss', '1', '2', '2018-12-30');

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `intro` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `sold` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO product VALUES ('1', '卡迪那', '24', '01.jpg', '5', '獨特的通心口造型，香脆口感加倍\r\n滿嘴誘人的蕃茄香，多層次口感在味蕾擴散開來\r\n', '50', '0');
INSERT INTO product VALUES ('2', '浪味仙', '24', '02.jpg', '5', '甜甜鹹鹹的美妙滋味、兒時回憶!\r\n五辛素植物，風味獨特\r\n口感絕佳，絕不含防腐劑', '50', '0');
INSERT INTO product VALUES ('3', '可樂果', '24', '03.jpg', '5', '堅持選用天然豌豆作為原料', '50', '0');
INSERT INTO product VALUES ('4', '樂事', '24', '04.jpg', '5', '爽口得好味道~~讓人一口接一口~\r\n', '50', '0');
INSERT INTO product VALUES ('5', '科學麵', '8', '05.jpg', '5', '童年的零食回憶\r\n鹹鹹脆脆好滋味\r\n吃出台灣味', '50', '0');
INSERT INTO product VALUES ('6', '義美夾心酥', '50', '06.jpg', '6', '層層酥脆\r\n一口接一口也不會膩', '50', '0');
INSERT INTO product VALUES ('7', '方塊酥', '100', '07.jpg', '6', '酥脆特殊的好口感\r\n多層次餅皮的香氣\r\n樸實甜美的風味', '50', '0');
INSERT INTO product VALUES ('8', '蜜蘭諾', '88', '08.jpg', '6', '歐洲大師手藝，傳承經典美味\r\n頂級白巧風味包覆百層派皮，香氣濃郁\r\n杏仁脆粒點綴口感細緻，風味優雅~\r\n', '50', '0');
INSERT INTO product VALUES ('9', '義美蛋捲', '63', '09.jpg', '6', '層層酥鬆，濃醇香氣， 每一口都是幸福滋味\r\n', '50', '0');
INSERT INTO product VALUES ('10', '爆米香', '70', '10.jpg', '6', '純手工捏製米香，保證使用合格原物料，米香一律蛋奶素喔！', '50', '0');
INSERT INTO product VALUES ('11', '孔雀餅乾', '32', '11.jpg', '6', '符合中元節慶澎派氣氛\r\n餅乾酥鬆口感&濃郁蛋香', '50', '0');
INSERT INTO product VALUES ('12', '森永牛奶糖', '11', '12.jpg', '4', '.森永牛奶糖', '50', '0');
INSERT INTO product VALUES ('13', '金門貢糖', '79', '13.jpg', '4', '香酥柔軟 甜而不膩\r\n入口即化 香味四溢\r\n金門貢糖人氣第一首選', '50', '5');
INSERT INTO product VALUES ('14', '牛軋糖', '20', '14.jpg', '4', '嚴選台灣北港11號花生採鮮烘\r\n入口時奶香味濃郁\r\nＱ軟不硬，不黏牙', '50', '4');
INSERT INTO product VALUES ('15', '乖乖軟糖', '39', '15.jpg', '4', '陪小朋友一起長大的乖乖\r\n外出郊遊的最佳夥伴\r\n經濟實惠的好選擇', '50', '3');
INSERT INTO product VALUES ('16', '嗨啾軟糖', '10', '16.jpg', '4', 'juicy up美味再升級!\r\n嗨啾繽紛變身更juicy!\r\n', '50', '2');
INSERT INTO product VALUES ('17', '77乳加巧克力', '8', '17.jpg', '3', '滑順牛奶巧克力MIX奶香牛軋糖\r\n每一口都有粒粒飽滿的花生顆粒', '50', '1');
INSERT INTO product VALUES ('18', '健達巧克力', '10', '18.jpg', '3', '牛奶巧克力含豐富牛奶內餡\r\n孩子喜歡，媽媽放心', '50', '0');
INSERT INTO product VALUES ('19', '大波露', '8', '19.jpg', '3', '香醇牛奶調配的牛奶巧克力\r\n濃郁滑順的好滋味令人難以抗拒\r\n永遠吃不膩的經典風味\r\n', '50', '0');
INSERT INTO product VALUES ('20', '雷神巧克力', '25', '20.jpg', '3', '日本原裝進口\r\n酥脆好滋味，讓你一口接一口\r\n點心零食好選擇', '50', '0');
INSERT INTO product VALUES ('21', '曾拌麵', '25', '21.jpg', '1', '各大綜藝節目介紹藝人朋友推薦\r\n美國權威部落客五星級評價\r\n手工製麵、改良波浪厚芯麵\r\n', '50', '0');
INSERT INTO product VALUES ('22', '詹麵 ', '25', '22.jpg', '1', '', '50', '0');
INSERT INTO product VALUES ('23', '老媽拌麵 ', '25', '23.jpg', '1', '各大綜藝節目介紹藝人朋友推薦\r\n美國權威部落客五星級評價\r\n手工製麵、改良波浪厚芯麵\r\n', '50', '0');
INSERT INTO product VALUES ('24', '滿漢大餐', '39', '24.jpg', '1', '各大綜藝節目介紹藝人朋友推薦\r\n美國權威部落客五星級評價\r\n手工製麵、改良波浪厚芯麵\r\n', '50', '0');
INSERT INTO product VALUES ('25', '來一客', '25', '25.jpg', '1', '各大綜藝節目介紹藝人朋友推薦\r\n美國權威部落客五星級評價\r\n手工製麵、改良波浪厚芯麵\r\n', '50', '0');
INSERT INTO product VALUES ('26', '雙響砲', '30', '26.jpg', '2', '一碗美味的雙響砲,cp值超高\r\n濃郁的口感,香氣逼人的美味\r\n療癒人心的美味!!\r\n', '50', '0');
INSERT INTO product VALUES ('27', '日清杯麵', '25', '27.jpg', '2', '日本原裝進口\r\n香醇濃郁的扇貝海鮮風味\r\n麵條香Q滑順', '50', '0');
INSERT INTO product VALUES ('28', '花雕雞麵', '39', '28.jpg', '2', '百年老店台酒公司\r\n獨家料理酒包、鮮嫩雞肉料理包\r\n濃郁的湯頭加上香Q的細麵\r\n', '50', '0');
INSERT INTO product VALUES ('29', '一度贊', '29', '29.jpg', '2', '新鮮豬肉加上獨特秘方調味\r\n獨特口味，老饕最愛', '50', '0');
INSERT INTO product VALUES ('30', '統一肉燥麵', '15', '30.jpg', '2', '道地熟悉的美味\r\n家鄉般的溫暖美味\r\n傳統熟悉的肉燥香味\r\n', '50', '0');
INSERT INTO product VALUES ('31', '維力炸醬麵 ', '15', '31.jpg', '2', '懷念的好味道麵體Q、料香濃獨特口味，老饕最愛', '50', '0');
INSERT INTO product VALUES ('33', '鱈魚香絲', '14', ' assert/img/product/32.jpg', '5', 'fish', '50', null);
INSERT INTO product VALUES ('34', '鱈魚', '14', ' assert/img/product/33.jpg', '2', 'fish', '50', '0');

-- ----------------------------
-- Table structure for `productreviews`
-- ----------------------------
DROP TABLE IF EXISTS `productreviews`;
CREATE TABLE `productreviews` (
  `name` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `time` date NOT NULL,
  `productid` int(11) NOT NULL,
  `star` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of productreviews
-- ----------------------------
INSERT INTO productreviews VALUES ('1111', 'good?', '2019-12-30', '1', '3');
INSERT INTO productreviews VALUES ('1111', 'comment2', '2019-12-30', '1', '4');
INSERT INTO productreviews VALUES ('1111', '33333', '2019-12-30', '1', '1');
INSERT INTO productreviews VALUES ('1111', 'WWWW', '2019-12-30', '1', '3');
INSERT INTO productreviews VALUES ('1111', 'nothing', '2019-12-30', '2', '5');
INSERT INTO productreviews VALUES ('1111', 'nothing????', '2019-12-30', '2', '3');

-- ----------------------------
-- Table structure for `producttype`
-- ----------------------------
DROP TABLE IF EXISTS `producttype`;
CREATE TABLE `producttype` (
  `typeid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of producttype
-- ----------------------------
INSERT INTO producttype VALUES ('1', 'drynoodle');
INSERT INTO producttype VALUES ('2', 'soupnoodle');
INSERT INTO producttype VALUES ('3', 'chocolate');
INSERT INTO producttype VALUES ('4', 'softcandy');
INSERT INTO producttype VALUES ('5', 'saltycookie');
INSERT INTO producttype VALUES ('6', 'sweetcookie');

-- ----------------------------
-- Table structure for `select`
-- ----------------------------
DROP TABLE IF EXISTS `select`;
CREATE TABLE `select` (
  `Image` varchar(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `singleprice` int(11) NOT NULL,
  `totalprice` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of select
-- ----------------------------

-- ----------------------------
-- Table structure for `select2`
-- ----------------------------
DROP TABLE IF EXISTS `select2`;
CREATE TABLE `select2` (
  `total` varchar(255) NOT NULL,
  `paymethod` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of select2
-- ----------------------------

-- ----------------------------
-- Table structure for `visitpeople`
-- ----------------------------
DROP TABLE IF EXISTS `visitpeople`;
CREATE TABLE `visitpeople` (
  `people` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of visitpeople
-- ----------------------------
INSERT INTO visitpeople VALUES ('26');
