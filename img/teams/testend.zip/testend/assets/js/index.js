function showscr6(){
	        scr6.style.display="block"
	           }