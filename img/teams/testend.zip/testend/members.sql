DROP TABLE IF EXISTS `members`;

CREATE TABLE `members` (
  `id` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `members` VALUES ('test','1234');
